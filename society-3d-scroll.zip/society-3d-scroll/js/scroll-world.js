/* ============================================
   SOCIETY — Scroll 3D World Engine
   Three.js (global) + Scroll-driven Camera
   ============================================ */

(function() {
  'use strict';

  // Check Three.js loaded
  if (typeof THREE === 'undefined') {
    console.error('Three.js not loaded');
    document.getElementById('fallback').classList.add('show');
    document.getElementById('loader').classList.add('hidden');
    return;
  }

  // ============================================
  // CONFIG
  // ============================================
  const CFG = {
    sceneCount: 3,
    sceneScroll: 1.4,
    transitionScroll: 0.5,
    fov: 60,
    fogDensity: 0.018,
    particleCount: 600,
    colors: {
      bg: 0x0a0a0f,
      accent: 0xa78bfa,
      green: 0x34d399,
      red: 0xf87171,
      blue: 0x60a5fa,
      yellow: 0xfbbf24,
      cyan: 0x22d3ee,
    }
  };

  // ============================================
  // STATE
  // ============================================
  let scene, camera, renderer, clock;
  let scrollY = 0, targetScrollY = 0;
  let currentScene = 0;
  let isMobile = false;
  let animId;
  const worlds = [];
  let globalPts;
  let ui = {};

  // ============================================
  // INIT
  // ============================================
  function init() {
    isMobile = window.matchMedia('(hover:none) and (pointer:coarse)').matches || window.innerWidth <= 860;

    scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(CFG.colors.bg, CFG.fogDensity);

    camera = new THREE.PerspectiveCamera(CFG.fov, window.innerWidth / window.innerHeight, 0.1, 1000);

    const container = document.getElementById('canvas-container');
    renderer = new THREE.WebGLRenderer({
      antialias: !isMobile,
      alpha: false,
      powerPreference: 'high-performance'
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, isMobile ? 1.5 : 2));
    renderer.setClearColor(CFG.colors.bg);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.appendChild(renderer.domElement);

    clock = new THREE.Clock();

    buildWorlds();
    buildParticles();
    buildLights();
    cacheUI();
    bindEvents();
    updateTrack();
    onScroll();

    setTimeout(function() {
      document.getElementById('loader').classList.add('hidden');
      animateStats();
    }, 2000);

    animate();
  }

  function cacheUI() {
    ui = {
      progress: document.getElementById('progress-fill'),
      copies: document.querySelectorAll('.scene-copy'),
      navs: document.querySelectorAll('.nav-item'),
      dots: document.querySelectorAll('.route-dot'),
      hint: document.getElementById('scroll-hint'),
      stats: document.getElementById('stats-overlay'),
    };
  }

  // ============================================
  // LIGHTS
  // ============================================
  function buildLights() {
    scene.add(new THREE.AmbientLight(0x404060, 0.5));
    const d = new THREE.DirectionalLight(0xffffff, 0.8);
    d.position.set(10, 20, 10);
    scene.add(d);
  }

  // ============================================
  // WORLD 0: RESEARCH
  // ============================================
  function buildResearchWorld() {
    const g = new THREE.Group();
    const c = CFG.colors.accent;

    // Core wireframe
    const core = new THREE.Mesh(
      new THREE.IcosahedronGeometry(2, 2),
      new THREE.MeshStandardMaterial({ color: c, emissive: c, emissiveIntensity: 0.4, metalness: 0.9, roughness: 0.1, wireframe: true })
    );
    g.add(core);

    // Inner glow
    const inner = new THREE.Mesh(
      new THREE.IcosahedronGeometry(1.2, 1),
      new THREE.MeshStandardMaterial({ color: c, emissive: c, emissiveIntensity: 0.8, metalness: 0.8, roughness: 0.2, transparent: true, opacity: 0.5 })
    );
    g.add(inner);

    // Nodes
    const nodeCount = isMobile ? 18 : 35;
    const nodes = [];
    const nodeGeo = new THREE.SphereGeometry(0.12, 8, 8);
    for (let i = 0; i < nodeCount; i++) {
      const col = i % 3 === 0 ? CFG.colors.green : i % 3 === 1 ? CFG.colors.blue : CFG.colors.cyan;
      const mat = new THREE.MeshStandardMaterial({ color: col, emissive: col, emissiveIntensity: 0.6 });
      const node = new THREE.Mesh(nodeGeo, mat);
      const a = (i / nodeCount) * Math.PI * 2;
      const r = 4 + Math.random() * 5;
      const h = (Math.random() - 0.5) * 7;
      node.position.set(Math.cos(a) * r, h, Math.sin(a) * r);
      node.userData = { a, r, h, speed: 0.2 + Math.random() * 0.4 };
      nodes.push(node);
      g.add(node);
    }

    // Connection lines
    const lineMat = new THREE.LineBasicMaterial({ color: c, transparent: true, opacity: 0.12 });
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        if (nodes[i].position.distanceTo(nodes[j].position) < 5) {
          const geo = new THREE.BufferGeometry().setFromPoints([nodes[i].position, nodes[j].position]);
          const line = new THREE.Line(geo, lineMat.clone());
          line.userData = { a: nodes[i], b: nodes[j] };
          g.add(line);
        }
      }
    }

    // Floating panels
    const panelCount = isMobile ? 5 : 10;
    for (let i = 0; i < panelCount; i++) {
      const p = new THREE.Mesh(
        new THREE.PlaneGeometry(1.5 + Math.random() * 1.5, 0.8 + Math.random()),
        new THREE.MeshStandardMaterial({ color: 0x1a1a2e, emissive: c, emissiveIntensity: 0.05, metalness: 0.5, roughness: 0.3, side: THREE.DoubleSide, transparent: true, opacity: 0.6 })
      );
      const a = Math.random() * Math.PI * 2;
      const r = 8 + Math.random() * 8;
      p.position.set(Math.cos(a) * r, (Math.random() - 0.5) * 10, Math.sin(a) * r);
      p.rotation.set(Math.random() * 0.5, Math.random() * Math.PI, Math.random() * 0.5);
      p.userData = { rx: (Math.random() - 0.5) * 0.004, ry: (Math.random() - 0.5) * 0.006, fs: 0.3 + Math.random() * 0.4, fo: Math.random() * Math.PI * 2 };
      g.add(p);
    }

    // Grid
    const grid = new THREE.GridHelper(50, 50, c, 0x1a1a2e);
    grid.position.y = -7;
    grid.material.transparent = true;
    grid.material.opacity = 0.25;
    g.add(grid);

    const light = new THREE.PointLight(c, 2, 30);
    light.position.set(0, 5, 0);
    g.add(light);

    return { group: g, type: 'research', core, inner, nodes };
  }

  // ============================================
  // WORLD 1: ALPHA
  // ============================================
  function buildAlphaWorld() {
    const g = new THREE.Group();
    const c = CFG.colors.yellow;

    // Main coin
    const coin = new THREE.Mesh(
      new THREE.CylinderGeometry(2.2, 2.2, 0.35, 32),
      new THREE.MeshStandardMaterial({ color: c, emissive: c, emissiveIntensity: 0.3, metalness: 1, roughness: 0.15 })
    );
    coin.rotation.x = Math.PI / 2;
    g.add(coin);

    // Rim
    const rim = new THREE.Mesh(
      new THREE.TorusGeometry(2.2, 0.06, 16, 64),
      new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: 0.7 })
    );
    g.add(rim);

    // Tokens
    const tokenCount = isMobile ? 20 : 40;
    const tokens = [];
    const geos = [
      new THREE.CylinderGeometry(0.35, 0.35, 0.07, 16),
      new THREE.OctahedronGeometry(0.45, 0),
      new THREE.TetrahedronGeometry(0.45, 0),
      new THREE.BoxGeometry(0.5, 0.5, 0.5),
    ];
    const cols = [c, CFG.colors.green, CFG.colors.accent, CFG.colors.red];

    for (let i = 0; i < tokenCount; i++) {
      const mat = new THREE.MeshStandardMaterial({
        color: cols[i % 4], emissive: cols[i % 4], emissiveIntensity: 0.4, metalness: 0.8, roughness: 0.2
      });
      const t = new THREE.Mesh(geos[i % 4], mat);
      const a = Math.random() * Math.PI * 2;
      const r = 5 + Math.random() * 10;
      const y = (Math.random() - 0.5) * 12;
      t.position.set(Math.cos(a) * r, y, Math.sin(a) * r);
      t.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
      t.userData = { a, r, speed: 0.1 + Math.random() * 0.25, baseY: y, rot: [(Math.random() - 0.5) * 0.015, (Math.random() - 0.5) * 0.015] };
      tokens.push(t);
      g.add(t);
    }

    // Sparkles
    const sGeo = new THREE.BufferGeometry();
    const sPos = new Float32Array(150 * 3);
    for (let i = 0; i < 150; i++) {
      sPos[i * 3] = (Math.random() - 0.5) * 25;
      sPos[i * 3 + 1] = (Math.random() - 0.5) * 18;
      sPos[i * 3 + 2] = (Math.random() - 0.5) * 25;
    }
    sGeo.setAttribute('position', new THREE.BufferAttribute(sPos, 3));
    const sparkles = new THREE.Points(sGeo, new THREE.PointsMaterial({ color: c, size: 0.12, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending }));
    g.add(sparkles);

    const light = new THREE.PointLight(c, 2, 30);
    light.position.set(0, 5, 0);
    g.add(light);

    return { group: g, type: 'alpha', coin, rim, tokens, sparkles };
  }

  // ============================================
  // WORLD 2: RAID
  // ============================================
  function buildRaidWorld() {
    const g = new THREE.Group();
    const c = CFG.colors.red;

    // X symbol
    const xg = new THREE.Group();
    const barMat = new THREE.MeshStandardMaterial({ color: c, emissive: c, emissiveIntensity: 0.5, metalness: 0.7, roughness: 0.2 });
    const b1 = new THREE.Mesh(new THREE.BoxGeometry(0.4, 4, 0.4), barMat);
    b1.rotation.z = Math.PI / 4;
    const b2 = new THREE.Mesh(new THREE.BoxGeometry(0.4, 4, 0.4), barMat);
    b2.rotation.z = -Math.PI / 4;
    xg.add(b1, b2);

    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(3.2, 0.05, 16, 64),
      new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: 0.5 })
    );
    ring.rotation.x = Math.PI / 2;
    xg.add(ring);
    g.add(xg);

    // Waves
    const waves = [];
    for (let i = 0; i < (isMobile ? 5 : 10); i++) {
      const w = new THREE.Mesh(
        new THREE.RingGeometry(3.5 + i * 1.3, 3.7 + i * 1.3, 64),
        new THREE.MeshBasicMaterial({ color: i % 2 === 0 ? c : CFG.colors.accent, transparent: true, opacity: 0.12 - i * 0.008, side: THREE.DoubleSide })
      );
      w.rotation.x = -Math.PI / 2;
      w.position.y = -2;
      w.userData = { idx: i, baseOp: 0.12 - i * 0.008 };
      waves.push(w);
      g.add(w);
    }

    // Engagements
    const engCount = isMobile ? 20 : 45;
    const engs = [];
    for (let i = 0; i < engCount; i++) {
      const type = i % 3;
      const geo = type === 0 ? new THREE.OctahedronGeometry(0.25, 0) : type === 1 ? new THREE.ConeGeometry(0.15, 0.4, 4) : new THREE.TetrahedronGeometry(0.25, 0);
      const col = type === 0 ? c : type === 1 ? CFG.colors.green : CFG.colors.yellow;
      const m = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: col, emissive: col, emissiveIntensity: 0.5, metalness: 0.6, roughness: 0.3 }));
      const a = Math.random() * Math.PI * 2;
      const r = 6 + Math.random() * 12;
      m.position.set(Math.cos(a) * r, (Math.random() - 0.5) * 10, Math.sin(a) * r);
      m.userData = { a, r, speed: 0.15 + Math.random() * 0.3, rise: 0.3 + Math.random() * 0.4, ro: Math.random() * Math.PI * 2 };
      engs.push(m);
      g.add(m);
    }

    // Grid
    const grid = new THREE.Mesh(
      new THREE.PlaneGeometry(70, 70, 35, 35),
      new THREE.MeshBasicMaterial({ color: c, wireframe: true, transparent: true, opacity: 0.06 })
    );
    grid.rotation.x = -Math.PI / 2;
    grid.position.y = -6;
    g.add(grid);

    const light = new THREE.PointLight(c, 2, 30);
    light.position.set(0, 5, 0);
    g.add(light);

    return { group: g, type: 'raid', xGroup: xg, waves, engs, grid };
  }

  // ============================================
  // BUILD ALL
  // ============================================
  function buildWorlds() {
    worlds.push(buildResearchWorld());
    worlds.push(buildAlphaWorld());
    worlds.push(buildRaidWorld());
    worlds.forEach(w => scene.add(w.group));
  }

  function buildParticles() {
    const count = isMobile ? 300 : CFG.particleCount;
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(count * 3);
    const cols = new Float32Array(count * 3);
    const palette = [
      new THREE.Color(CFG.colors.accent),
      new THREE.Color(CFG.colors.green),
      new THREE.Color(CFG.colors.blue),
      new THREE.Color(CFG.colors.cyan),
    ];
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 70;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 50;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 70;
      const col = palette[Math.floor(Math.random() * palette.length)];
      cols[i * 3] = col.r;
      cols[i * 3 + 1] = col.g;
      cols[i * 3 + 2] = col.b;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(cols, 3));
    globalPts = new THREE.Points(geo, new THREE.PointsMaterial({
      size: 0.08, vertexColors: true, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, sizeAttenuation: true
    }));
    scene.add(globalPts);
  }

  // ============================================
  // SCROLL
  // ============================================
  function updateTrack() {
    const total = (CFG.sceneCount * CFG.sceneScroll + (CFG.sceneCount - 1) * CFG.transitionScroll + 1) * window.innerHeight;
    document.getElementById('scroll-track').style.height = total + 'px';
  }

  function onScroll() {
    targetScrollY = window.scrollY || window.pageYOffset;
  }

  function jumpToScene(idx) {
    const vh = window.innerHeight;
    const seg = CFG.sceneScroll + CFG.transitionScroll;
    const pos = idx * seg * vh + CFG.sceneScroll * 0.5 * vh;
    window.scrollTo({ top: pos, behavior: 'smooth' });
  }

  function getSceneInfo(y) {
    const vh = window.innerHeight;
    const seg = CFG.sceneScroll + CFG.transitionScroll;
    const raw = y / (seg * vh);
    const si = Math.floor(raw);
    return {
      scene: Math.min(Math.max(si, 0), CFG.sceneCount - 1),
      progress: Math.min(Math.max(raw - si, 0), 1),
      total: Math.min(y / ((CFG.sceneCount * seg + 1) * vh), 1),
    };
  }

  // ============================================
  // UPDATE WORLDS
  // ============================================
  function updateWorlds(t, dt) {
    worlds.forEach(function(w, idx) {
      const active = idx === currentScene;
      const adj = Math.abs(idx - currentScene) <= 1;
      if (!active && !adj) return;

      if (w.type === 'research') {
        w.core.rotation.y += dt * 0.3;
        w.core.rotation.x += dt * 0.1;
        w.inner.rotation.y -= dt * 0.5;
        w.inner.rotation.z += dt * 0.2;

        w.nodes.forEach(function(n) {
          const d = n.userData;
          d.a += dt * d.speed * 0.3;
          n.position.x = Math.cos(d.a) * d.r;
          n.position.z = Math.sin(d.a) * d.r;
          n.position.y = d.h + Math.sin(t * d.speed + d.a) * 0.4;
        });

        w.group.children.forEach(function(c) {
          if (c.isLine && c.userData.a) {
            const p = c.geometry.attributes.position.array;
            p[0] = c.userData.a.position.x; p[1] = c.userData.a.position.y; p[2] = c.userData.a.position.z;
            p[3] = c.userData.b.position.x; p[4] = c.userData.b.position.y; p[5] = c.userData.b.position.z;
            c.geometry.attributes.position.needsUpdate = true;
          }
          if (c.isMesh && c.geometry.type === 'PlaneGeometry' && c.userData.rx) {
            c.rotation.x += c.userData.rx;
            c.rotation.y += c.userData.ry;
            c.position.y += Math.sin(t * c.userData.fs + c.userData.fo) * 0.002;
          }
        });
      }

      else if (w.type === 'alpha') {
        w.coin.rotation.y += dt * 0.5;
        w.rim.rotation.z -= dt * 0.3;

        w.tokens.forEach(function(t) {
          const d = t.userData;
          d.a += dt * d.speed * 0.2;
          t.position.x = Math.cos(d.a) * d.r;
          t.position.z = Math.sin(d.a) * d.r;
          t.position.y = d.baseY + Math.sin(t * d.speed + d.a) * 1.2;
          t.rotation.x += d.rot[0];
          t.rotation.y += d.rot[1];
        });

        w.sparkles.material.opacity = 0.5 + Math.sin(t * 2) * 0.25;
      }

      else if (w.type === 'raid') {
        const pulse = 1 + Math.sin(t * 3) * 0.05;
        w.xGroup.scale.set(pulse, pulse, pulse);
        w.xGroup.rotation.y += dt * 0.4;

        w.waves.forEach(function(wave) {
          const s = 1 + ((t * 0.3 + wave.userData.idx * 0.5) % 3);
          wave.scale.set(s, s, 1);
          wave.material.opacity = wave.userData.baseOp * (1 - (s - 1) / 3);
        });

        w.engs.forEach(function(e) {
          const d = e.userData;
          d.a += dt * d.speed * 0.25;
          e.position.x = Math.cos(d.a) * d.r;
          e.position.z = Math.sin(d.a) * d.r;
          e.position.y = Math.sin(t * d.rise + d.ro) * 5;
        });

        w.grid.material.opacity = 0.05 + Math.sin(t * 2) * 0.025;
      }
    });
  }

  // ============================================
  // CAMERA
  // ============================================
  var camPos = [
    { sx: 0, sy: 2, sz: 16, ex: 0, ey: 0, ez: 6 },
    { sx: 11, sy: 3, sz: 11, ex: 0, ey: 1, ez: 8 },
    { sx: -9, sy: 5, sz: 10, ex: 0, ey: 2, ez: 7 },
  ];
  var worldPos = [0, -28, -56];

  function updateCamera(t) {
    var info = getSceneInfo(scrollY);
    currentScene = info.scene;
    var prog = info.progress;
    scrollY += (targetScrollY - scrollY) * 0.08;

    var cp = camPos[currentScene];
    var dive = Math.min(prog / 0.7, 1);
    var ease = dive < 0.5 ? 4 * dive * dive * dive : 1 - Math.pow(-2 * dive + 2, 3) / 2;

    camera.position.x = cp.sx + (cp.ex - cp.sx) * ease;
    camera.position.y = cp.sy + (cp.ey - cp.sy) * ease;
    camera.position.z = cp.sz + (cp.ez - cp.sz) * ease;

    var lookX = Math.sin(t * 0.2) * 0.4;
    var lookY = Math.sin(t * 0.3) * 0.25;
    camera.lookAt(lookX, lookY, worldPos[currentScene]);

    worlds.forEach(function(w, idx) {
      var tp = worldPos[idx];
      if (idx < currentScene) {
        tp += 18 * (1 - Math.min(prog * 2, 1));
      } else if (idx > currentScene) {
        tp -= 18 * Math.min(prog * 2, 1);
      }
      w.group.position.z += (tp - w.group.position.z) * 0.06;

      var dist = Math.abs(idx - currentScene);
      var targetOp = dist === 0 ? 1 : dist === 1 ? 0.25 : 0;
      w.group.traverse(function(c) {
        if (c.material && c.material.transparent !== undefined) {
          var base = c.userData.baseOp || 1;
          c.material.opacity += (targetOp * base - c.material.opacity) * 0.05;
        }
      });
      w.group.visible = Math.abs(w.group.position.z - camera.position.z) < 90;
    });

    updateUI(info);
  }

  function updateUI(info) {
    var s = info.scene, tp = info.total;
    if (ui.progress) ui.progress.style.transform = 'scaleX(' + tp + ')';

    ui.copies.forEach(function(c, idx) {
      c.classList.toggle('active', idx === s);
      if (idx === s) {
        var pr = info.progress;
        var yo = (0.5 - pr) * 25;
        c.style.transform = 'translateY(calc(-50% + ' + yo + 'px))';
      }
    });

    ui.navs.forEach(function(n, idx) { n.classList.toggle('active', idx === s); });
    ui.dots.forEach(function(d, idx) { d.classList.toggle('active', idx === s); });
    if (ui.hint) ui.hint.classList.toggle('hidden', tp > 0.12);
    if (ui.stats) ui.stats.style.opacity = tp > 0.92 ? '0' : '1';
  }

  function updateParticles(t) {
    if (!globalPts) return;
    var p = globalPts.geometry.attributes.position.array;
    for (var i = 0; i < p.length; i += 3) {
      p[i + 1] += Math.sin(t * 0.5 + p[i] * 0.1) * 0.004;
      if (p[i + 1] > 25) p[i + 1] = -25;
      if (p[i + 1] < -25) p[i + 1] = 25;
    }
    globalPts.geometry.attributes.position.needsUpdate = true;
    globalPts.rotation.y = t * 0.015;
  }

  // ============================================
  // STATS
  // ============================================
  function animateStats() {
    var stats = [
      { el: document.getElementById('stat-members'), t: 12500 },
      { el: document.getElementById('stat-alpha'), t: 340 },
      { el: document.getElementById('stat-raids'), t: 89 },
    ];
    stats.forEach(function(s) {
      if (!s.el) return;
      var cur = 0, inc = s.t / 50;
      var iv = setInterval(function() {
        cur += inc;
        if (cur >= s.t) { cur = s.t; clearInterval(iv); }
        s.el.textContent = Math.floor(cur).toLocaleString() + (s.t > 1000 ? '+' : '');
      }, 35);
    });
  }

  // ============================================
  // EVENTS
  // ============================================
  function bindEvents() {
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onResize);

    document.querySelectorAll('.nav-item, .route-dot').forEach(function(btn) {
      btn.addEventListener('click', function() {
        jumpToScene(parseInt(this.dataset.scene));
      });
    });
  }

  function onResize() {
    var w = window.innerWidth, h = window.innerHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
    isMobile = window.matchMedia('(hover:none) and (pointer:coarse)').matches || w <= 860;
    updateTrack();
  }

  // ============================================
  // LOOP
  // ============================================
  function animate() {
    animId = requestAnimationFrame(animate);
    var dt = clock.getDelta();
    var t = clock.getElapsedTime();
    updateCamera(t);
    updateWorlds(t, dt);
    updateParticles(t);
    renderer.render(scene, camera);
  }

  window.addEventListener('beforeunload', function() {
    if (animId) cancelAnimationFrame(animId);
    renderer.dispose();
  });

  // Start
  init();
})();
