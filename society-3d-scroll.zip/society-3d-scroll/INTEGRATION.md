# 🚀 Integrasi ke Website Society (GitHub → Vercel)

## ❌ Kenapa Tadi Jadi Broken?

Dari screenshot Anda, masalahnya:
1. **CSS tidak ke-load** → Background putih, font Times New Roman, layout hancur
2. **Three.js ES module gagal** → Canvas 3D tidak muncul
3. **Dibuka langsung dari file** (`file://`) atau server lokal tanpa proper setup

## ✅ Yang Sudah Diperbaiki

- **Three.js** sekarang pakai CDN script tag (bukan ES module) → 100% work di mana pun
- **CSS critical di-inline** di `<head>` → Styling muncul instant meski external CSS gagal
- **Fallback message** kalau WebGL tidak support
- **Mobile-first** layout yang benar

---

## 📥 Cara 1: Standalone Page (Paling Mudah)

Cocok kalau mau page terpisah seperti `/3d-world`

### Step 1: Download & Extract
```bash
# Di Linux terminal
cd ~/Downloads
unzip society-3d-scroll.zip -d society-3d-scroll/
```

### Step 2: Copy ke Repo
```bash
cd ~/society   # folder repo GitHub Anda
mkdir -p public/3d-world
cp -r ~/Downloads/society-3d-scroll/* public/3d-world/
```

### Step 3: Commit & Push
```bash
git add public/3d-world/
git commit -m "Add 3D scroll world landing page"
git push origin main
```

### Step 4: Akses
```
https://society-community.vercel.app/3d-world
```

---

## 🔗 Cara 2: Embed ke Halaman Utama

Kalau mau 3D world jadi **section pertama** di homepage:

### Edit `index.html` (atau `pages/index.tsx` kalau Next.js)

Tambahkan di **atas sekali** (sebelum semua content):

```html
<!-- 3D World Section -->
<div id="scroll-world-wrapper" style="position:relative;width:100%;">
  <div id="canvas-container" style="position:fixed;inset:0;z-index:1;"></div>
  <div id="scroll-track" style="height:400vh;position:relative;z-index:0;"></div>

  <!-- UI Overlay -->
  <div id="ui-layer" style="position:fixed;inset:0;z-index:10;pointer-events:none;">
    <!-- Copy semua UI element dari index.html -->
  </div>
</div>

<!-- Content website Anda yang sudah ada -->
<div id="main-content">
  <!-- ... existing content ... -->
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r160/three.min.js"></script>
<script src="/js/scroll-world.js"></script>
```

### Copy file JS
```bash
cp society-3d-scroll/js/scroll-world.js public/js/
# atau ke folder static Anda
```

---

## ⚛️ Cara 3: Next.js / React Integration

Kalau website Society pakai **Next.js** (karena deploy di Vercel):

### 1. Install Three.js
```bash
npm install three
npm install -D @types/three   # kalau pakai TypeScript
```

### 2. Buat Component
Buat file `components/ScrollWorld.tsx`:

```tsx
import { useEffect, useRef } from 'react';

export default function ScrollWorld() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Load script dynamically
    const script = document.createElement('script');
    script.src = '/js/scroll-world.js';
    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  return (
    <div style={{ position: 'relative', width: '100%' }}>
      <div id="canvas-container" ref={containerRef} style={{ position: 'fixed', inset: 0, zIndex: 1 }} />
      <div id="scroll-track" style={{ height: '400vh', position: 'relative' }} />
      {/* UI Layer */}
      <div id="ui-layer" style={{ position: 'fixed', inset: 0, zIndex: 10, pointerEvents: 'none' }}>
        {/* Copy UI dari index.html */}
      </div>
    </div>
  );
}
```

### 3. Gunakan di `pages/index.tsx`
```tsx
import ScrollWorld from '@/components/ScrollWorld';

export default function Home() {
  return (
    <>
      <ScrollWorld />
      {/* Rest of your page */}
    </>
  );
}
```

---

## 🐧 One-Liner Linux (Copy-Paste Langsung)

```bash
# 1. Clone repo (kalau belum)
cd ~ && git clone https://github.com/rann-xyz/society.git && cd society

# 2. Download & extract file
mkdir -p public/3d-world
curl -L "https://cdn.jsdelivr.net/gh/rann-xyz/society@main/public/3d-world/index.html" 2>/dev/null || echo "Manual: copy file ZIP ke public/3d-world/"

# 3. Copy file dari ZIP (ganti path sesuai lokasi ZIP)
cp -r /path/to/society-3d-scroll/* public/3d-world/

# 4. Commit & push
git add public/3d-world/
git commit -m "Add 3D scroll world effect"
git push origin main
```

---

## 🧪 Test Local

```bash
# Masuk ke folder
cd society/public/3d-world

# Serve dengan Python
python3 -m http.server 8000
# Buka http://localhost:8000

# ATAU dengan Node
npx serve .
# ATAU dengan PHP
php -S localhost:8000
```

**Jangan buka file langsung** (`file:///...`) karena browser akan block external resources!

---

## 🎨 Customization

### Ganti Warna
Edit di `js/scroll-world.js`:
```js
const CFG = {
  colors: {
    accent: 0xa78bfa,   // Ungu
    green: 0x34d399,    // Hijau
    red: 0xf87171,      // Merah
    // ...
  }
};
```

### Ganti Text
Edit langsung di `index.html` dalam elemen `.scene-copy`

### Kurangi Objek (untuk performa)
```js
const nodeCount = isMobile ? 12 : 25;   // default: 18/35
const tokenCount = isMobile ? 15 : 30;  // default: 20/40
```

---

## 🆘 Troubleshooting

| Masalah | Solusi |
|---------|--------|
| Background putih | Refresh page / clear cache (Ctrl+Shift+R) |
| Canvas tidak muncul | Cek console (F12) → kalau "THREE is not defined", cek koneksi internet |
| Scroll tidak jalan | Pastikan `#scroll-track` ada dan tingginya > viewport |
| Mobile aneh | Cek viewport meta tag sudah ada |
| Font jelek | Pastikan Google Fonts ter-load (koneksi internet) |

---

Built for Society Community 🚀
